This will be a site that will help countless of spinning instructors all over the world.
Our plan is to make a tool that helps immensly.

all of this will only be possible because spotify did an awesome job with their API.

i dont have time to make a good readme i have to get back to coding

The site: https://dradshere.github.io/spinning-site/ (hosted on github)
