    <script>
        window.onload = function() {
            window.location.href='https://dradshere.github.io/spinning-site/login'
        };
    </script>
