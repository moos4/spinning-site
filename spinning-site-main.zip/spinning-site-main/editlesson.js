function openaddsong_gui() { document.getElementById("addsong_gui").style.visibility = "visible"; }
function closeaddsong_gui() { document.getElementById("addsong_gui").style.visibility = "hidden"; }