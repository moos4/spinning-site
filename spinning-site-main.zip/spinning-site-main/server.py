def main():
    print("werkt dit")

main()